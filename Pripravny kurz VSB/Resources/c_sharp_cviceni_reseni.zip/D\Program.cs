namespace D {
    internal class Program {
        static void Main(string[] args) {
            Console.WriteLine("Vyber program:");
            Console.WriteLine(" 1 - Počet žáků");
            Console.WriteLine(" 2 - Kontrola účtenek");
            Console.WriteLine(" 3 - Posloupnost");
            Console.WriteLine(" 4 - Nejvyšší žák");
            Console.WriteLine(" 5 - Hrátky s čísly");
            Console.WriteLine(" 6 - Hádání čísel");
            Console.WriteLine(" 7 - Hod kostkou");
            Console.WriteLine(" 8 - Opakované zadávání znaku");
            Console.WriteLine(" 9 - Teploty");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1: D01PocetZaku.Mainx();        break;
                case 2: D02UctenkyKontrola.Mainx();  break;
                case 3: D03Posloupnost.Mainx();        break;
                case 4: D04NejvyssiZak.Mainx();       break;
                case 5: D05HratkySCisly.Mainx();     break;
                case 6: D06HadaniCisla.Mainx();        break;
                case 7: D07HodKostkou.Mainx();         break;
                case 8: D08OpakovaneZnaky.Mainx();     break;
                case 9: D09Teploty.Mainx();             break;
                default: Console.WriteLine("Neplatná volba!"); break;
            }
        }
    }

    // 1) Zadejte postupně, kolik je v každé třídě žáků (0=konec). Program spočítá, kolik je žáků v celé škole
    // a průměrný počet žáků ve třídě. Nula do platných dat nepatří.
    internal class D01PocetZaku {
        public static void Mainx() {
            int zaciTrida;
            double zaciPrumer, zaciCelkem = 0;
            byte pocetTrid = 0;

            do {
                Console.Write("Zadejte počet žáků ve třídě [0 ukončí]: ");
                zaciTrida = Convert.ToInt32(Console.ReadLine());
                if (zaciTrida > 0) {
                    pocetTrid++;
                    zaciCelkem += zaciTrida;
                }
            } while (zaciTrida != 0);

            if (pocetTrid > 0) {
                zaciPrumer = zaciCelkem / pocetTrid;
                Console.WriteLine($"Celkem {pocetTrid} tříd, {zaciCelkem} žáků, průměr {zaciPrumer:F1} žáků na třídu.");
            }
            else {
                Console.WriteLine("Nebyla zadána žádná třída.");
            }
        }
    }

    // 2) Máte účtenky z různých nákupů, kolik jich je nevíte. Jako poslední zadáte nulu.
    // Program spočítá celkovou útratu a kolik nákupů přesáhlo 100 Kč.
    internal class D02UctenkyKontrola {
        public static void Mainx() {
            int pocetUct100Plus = 0;
            double nakup, sumaNakup = 0;

            do {
                Console.Write("Zadejte částku za nákup [0 ukončí]: ");
                nakup = Convert.ToDouble(Console.ReadLine());
                if (nakup > 0) {
                    sumaNakup += nakup;
                    if (nakup > 100)
                        pocetUct100Plus++;
                }
            } while (nakup != 0);

            Console.WriteLine($"Celkem utraceno: {sumaNakup:F2} Kč, nákupů nad 100 Kč: {pocetUct100Plus}");
        }
    }

    // 3) Zadejte první, druhý a poslední člen lineární posloupnosti.
    // Program vytiskne pod sebou všechny prvky posloupnosti.
    internal class D03Posloupnost {
        public static void Mainx() {
            int prvni, druhy, posledni;

            Console.Write("Zadejte první číslo posloupnosti: ");
            prvni = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zadejte druhé číslo posloupnosti: ");
            druhy = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zadejte poslední číslo posloupnosti: ");
            posledni = Convert.ToInt32(Console.ReadLine());

            int rozdil = druhy - prvni;
            int aktualni = prvni;

            // Vypíše všechny členy od prvního po poslední včetně
            if (rozdil > 0) {
                while (aktualni <= posledni) {
                    Console.WriteLine(aktualni);
                    aktualni += rozdil;
                }
            } else if (rozdil < 0) {
                while (aktualni >= posledni) {
                    Console.WriteLine(aktualni);
                    aktualni += rozdil;
                }
            } else {
                Console.WriteLine("Rozdíl je nula – nekonečná posloupnost.");
            }
        }
    }

    // 4) Program postupně čte jméno a výšku žáka. Prázdné jméno ukončuje.
    // Poté zobrazí jméno a výšku nejvyššího žáka.
    internal class D04NejvyssiZak {
        public static void Mainx() {
            double nejvyssiVyska = 0, vyskaZaka;
            string jmenoNejvyssiho = "", jmenoZaka;

            Console.Write("Zadejte jméno žáka [Enter ukončí]: ");
            jmenoZaka = Console.ReadLine();

            while (jmenoZaka.Length > 0) {
                Console.Write("Zadejte výšku žáka [cm]: ");
                vyskaZaka = Convert.ToDouble(Console.ReadLine());

                if (vyskaZaka > nejvyssiVyska) {
                    jmenoNejvyssiho = jmenoZaka;
                    nejvyssiVyska = vyskaZaka;
                }

                Console.Write("Zadejte jméno žáka [Enter ukončí]: ");
                jmenoZaka = Console.ReadLine();
            }

            if (jmenoNejvyssiho.Length > 0)
                Console.WriteLine($"Nejvyšší žák je {jmenoNejvyssiho} ({nejvyssiVyska} cm).");
            else
                Console.WriteLine("Nebyl zadán žádný žák.");
        }
    }

    // 5) Zadejte řadu celých čísel ukončenou nulou. Program vypíše čísla, počet, součet, průměr,
    // minimum, maximum, sudá čísla a čísla větší než první.
    internal class D05HratkySCisly {
        public static void Mainx() {
            int vstupCislo, sumaC = 0, minC = 0, maxC = 0, sudePocet = 0, celkemC = 0, prvniC = 0;
            string vsechnyC = "", sudaC = "", vetsiC = "";
            bool prvniPruchod = true;

            do {
                Console.Write("Zadejte číslo [0 ukončí]: ");
                vstupCislo = Convert.ToInt32(Console.ReadLine());

                if (prvniPruchod) {
                    minC = maxC = prvniC = vstupCislo;
                    prvniPruchod = false;
                }
                if (vstupCislo != 0) {
                    sumaC += vstupCislo;
                    celkemC++;
                    minC = Math.Min(minC, vstupCislo);
                    maxC = Math.Max(maxC, vstupCislo);
                    vsechnyC += $" {vstupCislo}";
                    if (vstupCislo % 2 == 0) { sudePocet++; sudaC += $" {vstupCislo}"; }
                    if (vstupCislo > prvniC) vetsiC += $" {vstupCislo}";
                }
            } while (vstupCislo != 0);

            Console.WriteLine($"Čísla:   {vsechnyC}");
            Console.WriteLine($"Počet:   {celkemC}");
            Console.WriteLine($"Součet:  {sumaC}");
            Console.WriteLine($"Průměr:  {(double)sumaC / celkemC:F2}");
            Console.WriteLine($"Minimum: {minC}");
            Console.WriteLine($"Maximum: {maxC}");
            Console.WriteLine($"Sudá ({sudePocet}):{sudaC}");
            Console.WriteLine($"Větší než první ({prvniC}):{vetsiC}");
        }
    }

    // 6) Program si náhodně vygeneruje číslo z intervalu <1,10>. Hádáte, dokud se nestrefíte.
    internal class D06HadaniCisla {
        public static void Mainx() {
            Random rand = new Random();
            int cislo, vstup;

            cislo = rand.Next(1, 11);

            do {
                Console.Write("Hádej číslo 1–10: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup < cislo) Console.WriteLine("Více!");
                else if (vstup > cislo) Console.WriteLine("Méně!");
            } while (vstup != cislo);

            Console.WriteLine($"Správně! Hádané číslo bylo {cislo}.");
        }
    }

    // 7) Program hází kostkou tak dlouho, dokud nepadne šestka. Vypíše počet hodů.
    internal class D07HodKostkou {
        public static void Mainx() {
            Random rand = new Random();
            int hod, pokus = 0;

            do {
                hod = rand.Next(1, 7);
                pokus++;
            } while (hod != 6);

            Console.WriteLine($"Pro hození šestky bylo třeba {pokus} pokusů.");
        }
    }

    // 8) Uživatel opakovaně zadává znak, program odpoví, zda jde o písmeno, číslici nebo jiný znak.
    // Zadávání končí zadáním nuly.
    internal class D08OpakovaneZnaky {
        public static void Mainx() {
            char znak;

            do {
                Console.Write("Zadejte znak [0 ukončí]: ");
                znak = Convert.ToChar(Console.ReadLine());

                if (znak != '0') {
                    if ((znak >= 'a' && znak <= 'z') || (znak >= 'A' && znak <= 'Z'))
                        Console.WriteLine($"'{znak}' je písmeno.");
                    else if (znak >= '1' && znak <= '9')
                        Console.WriteLine($"'{znak}' je číslice.");
                    else
                        Console.WriteLine($"'{znak}' je jiný znak.");
                }
            } while (znak != '0');
        }
    }

    // 9) Uživatel zadává teploty (teplota > 100 ukončí). Program zobrazí zadané teploty,
    // maximální teplotu a její pořadí.
    internal class D09Teploty {
        public static void Mainx() {
            double teplotaVstup, teplotaMax = 0;
            int poradiMax = 0, poradi = 0;
            string vypis = "";

            Console.Write("Zadejte teplotu [>100 ukončí]: ");
            teplotaVstup = Convert.ToDouble(Console.ReadLine());

            while (teplotaVstup <= 100) {
                poradi++;
                if (poradi == 1) {
                    vypis = teplotaVstup.ToString();
                    teplotaMax = teplotaVstup;
                    poradiMax = 1;
                }
                else {
                    vypis += $", {teplotaVstup}";
                    if (teplotaVstup > teplotaMax) {
                        teplotaMax = teplotaVstup;
                        poradiMax = poradi;
                    }
                }

                Console.Write("Zadejte teplotu [>100 ukončí]: ");
                teplotaVstup = Convert.ToDouble(Console.ReadLine());
            }

            if (poradi == 0) {
                Console.WriteLine("Nebyla zadána žádná teplota.");
            }
            else {
                Console.WriteLine($"Zadané teploty: {vypis}");
                Console.WriteLine($"Maximální teplota: {teplotaMax} °C (zadána jako {poradiMax}. v pořadí)");
            }
        }
    }
}

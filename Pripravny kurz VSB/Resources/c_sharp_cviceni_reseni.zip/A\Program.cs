﻿namespace A {
    internal class Program {
        //----------------------------------------------------------------------------------
        //POZOR! Toto jsou možná řešení cvičných programů, ne jediná možná správná řešení! 
        //Soustřeďte se na to, aby vám program vracel správný výsledek,
        //a ne na to, že to musí být napsáno úplně stejně jako zde.
        //----------------------------------------------------------------------------------

        static void Main(string[] args) {
            Console.WriteLine("Vyber program:");
            Console.WriteLine(" 0 - Hello World");
            Console.WriteLine(" 1 - Počet hodin a dnů");
            Console.WriteLine(" 3 - Průměrná teplota");
            Console.WriteLine(" 4 - Převod jednotek (m/s -> km/h)");
            Console.WriteLine(" 5 - Banka - úroky");
            Console.WriteLine(" 6 - Obvod, obsah kruhu");
            Console.WriteLine(" 7 - Množství vody v sudu");
            Console.WriteLine(" 8 - Druhá mocnina");
            Console.WriteLine(" 9 - Očekávaný zisk");
            Console.WriteLine("10 - Převod radian to degress");
            Console.WriteLine("11 - Běžec průměrná rychlost");
            Console.WriteLine("12 - Kolik tun vody v bazénu");
            Console.WriteLine("13 - Výpočet přepony trojúhelníku");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 0:
                    A00HelloWorld.Mainx();
                    break;
                case 1:
                    A01PocetHodinDnu.Mainx();
                    break;
                case 3:
                    A03PrumernaTeplotaDen.Mainx();
                    break;
                case 4:
                    A04PrevodJednotky.Mainx();
                    break;
                case 5:
                    A05BankaUrok.Mainx();
                    break;
                case 6:
                    A06ObvodKruhu.Mainx();
                    break;
                case 7:
                    A07Sudy.Mainx();
                    break;
                case 8:
                    A08Mocnina.Mainx();
                    break;
                case 9:
                    A09ZiskProcenta.Mainx();
                    break;
                case 10:
                    A10StupneRadiany.Mainx();
                    break;
                case 11:
                    A11BezecTrat.Mainx();
                    break;
                case 12:
                    A12Bazen.Mainx();
                    break;
                case 13:
                    A13Pythagoras.Mainx();
                    break;
                default:
                    Console.WriteLine("Neplatná volba!");
                    break;
            }
        }
    }
    internal class A00HelloWorld {
        public static void Mainx() {
            Console.WriteLine("01000001 01101000 01101111 01101010 — čili Ahoj!");
        }

    }
    // 1) Zadejte počet dnů a hodin. Program vypočte, kolik je to hodin (výsledek může být reálné číslo)
    internal class A01PocetHodinDnu {
        public static void Mainx() {
            int den, hodin;
            Console.WriteLine("Zadej počet dnů [celé číslo]");
            den = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Zadej počet hodin [celé číslo]");
            hodin = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"celkem to je :{den * 24 + hodin}");
        }
    }
    // 3) Zadejte teplotu v 6,12 a 18 hodin. Vytiskne se průměrná denní teplota.
    internal class A03PrumernaTeplotaDen {
        public static void Mainx() {
            double teplota6, teplota12, teplota18;

            Console.WriteLine("Zadej teplotu v 6:00");
            teplota6 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Zadej teplotu v 12:00");
            teplota12 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Zadej teplotu v 18:00");
            teplota18 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"Průměrná teplota byla: {(teplota6 + teplota12 + teplota18) / 3,2:f2}");
        }
    }

    // 4) Zadejte rychlost v m/s a převeďte na km/hod. 
    internal class A04PrevodJednotky {
        public static void Mainx() {
            double rychlostMs;
            Console.WriteLine("Zadejte rychlost v m/s");
            rychlostMs = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"{rychlostMs} m/s je: {rychlostMs * 3.6} km/h");
        }
    }
    // 5) Zadejte částku peněz, které jsou uloženy v bance, úrok a délku uložení.
    // Vypočítejte, kolik bude v bance po uplynutí uvedené doby.Nepočítejte úroky z úroků.
    internal class A05BankaUrok {
        public static void Mainx() {
            double castka, urok, vysledekUlozky;
            int delkaUlozky;
            Console.WriteLine("Zadej částku k uložení");
            castka = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej úrok[%]");
            urok = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej délku uložky [celé roky]");
            delkaUlozky = Convert.ToInt32(Console.ReadLine());
            vysledekUlozky = castka + (castka * urok / 100) * Convert.ToDouble(delkaUlozky);
            Console.WriteLine($"Po uplynutí bude v bance: {vysledekUlozky} peněz.");

        }
    }
    // 6) Zadejte poloměr kruhu. Vypočítejte obvod (o=2r) a plochu (P=r2).
    internal class A06ObvodKruhu {
        public static void Mainx() {
            double polomer, obvod, plocha;
            const double PI = 3.14; // zaokrouhleno pro účely cvičení; přesnou hodnotu nabízí vestavěné Math.PI
            Console.WriteLine("Zadejte poloměr kruhu [cm]");
            polomer = Convert.ToDouble(Console.ReadLine());
            obvod = 2 * PI * polomer;
            plocha = PI * Math.Pow(polomer, 2);
            Console.WriteLine($"Obvod kruhu je: {Math.Round(obvod, 2)} cm Obsah kruhu je: {Math.Round(plocha, 2)} cm2");
        }
    }
    // 7) Zadejte počet sudů a množství litrů v sudu (ve všech je stejně). Kolik litrů je celkem?
    internal class A07Sudy {
        public static void Mainx() {
            int pocetSudu, mnozstviVody, celkemVody;
            Console.WriteLine("Zadejte počet sudů[celé číslo]:");
            pocetSudu = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Zadejte množství vody [celé číslo]");
            mnozstviVody = Convert.ToInt32(Console.ReadLine());
            celkemVody = pocetSudu * mnozstviVody;
            Console.WriteLine($"Celkem je v sudech {celkemVody} litrů vody.");
        }
    }
    // 8) Zadejte číslo, počítač vypíše: Druhá mocnina čísla... je...
    internal class A08Mocnina {
        public static void Mainx() {
            double zadaneCislo;
            Console.WriteLine("Zadejte číslo k umocnění");
            zadaneCislo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"Druhá mocnina čísla: {zadaneCislo} je: {Math.Pow(zadaneCislo, 2)}");
        }
    }
    // 9) Z klávesnice se zadá očekávaný a skutečný zisk. Počítač oznámí, kolika procent bylo dosaženo.
    internal class A09ZiskProcenta {
        public static void Mainx() {
            double ocekavanyZisk, skutecnyZisk, celkemProcent;
            Console.WriteLine("Zadejte očekávaný zisk v Kč: ");
            ocekavanyZisk = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte skutečný zisk v Kč: ");
            skutecnyZisk = Convert.ToDouble(Console.ReadLine());
            celkemProcent = 100 * skutecnyZisk / ocekavanyZisk;
            Console.WriteLine($"Bylo dosaženo {celkemProcent} % očekávaného zisku.");
        }
    }
    // 10) Převeďte úhel zadaný v radiánech na stupně.
    internal class A10StupneRadiany {
        public static void Mainx() {
            double radian, stupne;
            Console.WriteLine("Zadejte radiany:");
            radian = Convert.ToDouble(Console.ReadLine());
            stupne = radian * (180 / Math.PI);
            Console.WriteLine($"{radian} radiánů je: {stupne} stupňů");
        }
    }
    // 11) Sestavte program, který se zeptá na délku běžecké trati v metrech a poté na čas běžce na této trati ve vteřinách.
    // Poté zobrazí, jakou průměrnou rychlostí v[km / hod] běžec běžel. (program Doc. Homoly) ̈
    internal class A11BezecTrat {
        public static void Mainx() {
            double delkaTrati, casBezce, prumRychlostBezce;
            Console.WriteLine("Zadejte délku trati[m]: ");
            delkaTrati = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej vysledný čas běžce[s]: ");
            casBezce = Convert.ToDouble(Console.ReadLine());
            prumRychlostBezce = (delkaTrati / casBezce) * 3.6;
            Console.WriteLine($"Průměrná rychlost běžce byla: {prumRychlostBezce} km/h");
        }
    }
    // 12) Sestavte program, který se zeptá na průměr vašeho kruhového bazénu a poté na jeho výšku (obojí v metrech).
    // Poté zobrazí, kolik tun vody se do něj vejde(1 m3 vody = 1 tuna). (program Doc. Homoly)
    internal class A12Bazen {
        public static void Mainx() {
            double bazenPrumer, bazenVyska, bazenHmotnost;
            Console.WriteLine("Zadejte průměr bazénu[m]: ");
            bazenPrumer = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte výšku bazénu[m]: ");
            bazenVyska = Convert.ToDouble(Console.ReadLine());
            bazenHmotnost = Math.PI * Math.Pow(bazenPrumer / 2, 2) * bazenVyska;
            Console.WriteLine($"V bazénu je: {bazenHmotnost} tun");
        }
    }
    // 13) Zadejte délku odvěsen pravoúhlého trojúhelníka. Program pomocí Pythagorovy věty vypočte délku přepony.
    // Pro kontrolu: zadáte-li odvěsny o délce 3 a 4, pak výsledek je 5
    // (přesněji 5,0, protože výsledek odmocniny se musí ukládat do desetinného typu )
    internal class A13Pythagoras {
        public static void Mainx() {
            double odvesnaA, odvesnaB, prepona;
            Console.WriteLine("Zadejte délku odvěsny A[cm]: ");
            odvesnaA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte délku odvěsny B[cm]:");
            odvesnaB = Convert.ToDouble(Console.ReadLine());
            prepona = Math.Sqrt(Math.Pow(odvesnaA, 2) + Math.Pow(odvesnaB, 2));
            Console.WriteLine($"Délka přepony je: {prepona} cm");
        }
    }
}
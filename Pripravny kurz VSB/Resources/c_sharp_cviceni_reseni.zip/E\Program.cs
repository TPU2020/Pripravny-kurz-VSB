namespace E {
    internal class Program {
        static void Main(string[] args) {
            Console.WriteLine("Vyber program:");
            Console.WriteLine(" 1 - Nejmenší číslo v řadě");
            Console.WriteLine(" 2 - Kolikrát bylo zadáno číslo X");
            Console.WriteLine(" 3 - Statistika hodů kostkou");
            Console.WriteLine(" 4 - Sportka bez opakování");
            Console.WriteLine(" 5 - Součet, průměr, max, min v oddělených cyklech");
            Console.WriteLine(" 6 - Náhodné slovo ze zadaných písmen");
            Console.WriteLine(" 7 - Hledání slova v poli");
            Console.WriteLine(" 8 - Slova v obráceném pořadí, sudá a lichá");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1: E01RadaCisel.Mainx();          break;
                case 2: E02HledaniCisla.Mainx();       break;
                case 3: E03KostkaStatistika.Mainx();   break;
                case 4: E04SportkaUnikatni.Mainx();    break;
                case 5: E05PoleOperace.Mainx();        break;
                case 6: E06NahodneSlovo.Mainx();       break;
                case 7: E07HledaniSlova.Mainx();       break;
                case 8: E08SlovaObracene.Mainx();      break;
                default: Console.WriteLine("Neplatná volba!"); break;
            }
        }
    }

    // 1) Zadejte řadu čísel ukončenou nulou. Zjistěte nejmenší a vypište, kolikrát se v řadě opakuje.
    internal class E01RadaCisel {
        public static void Mainx() {
            int nejmensi = 0, pocetOpakovani = 0, celkemZadano, zadaneCislo;
            int[] radaCisel = new int[99];
            int i = 0;
            bool prvniPrubeh = true;

            do {
                Console.Write("Zadejte číslo [0 ukončí]: ");
                zadaneCislo = Convert.ToInt32(Console.ReadLine());
                radaCisel[i] = zadaneCislo;
                i++;
            } while (zadaneCislo != 0);
            celkemZadano = i - 1;

            for (i = 0; i < celkemZadano; i++) {
                if (prvniPrubeh) {
                    nejmensi = radaCisel[i];
                    pocetOpakovani = 1;
                    prvniPrubeh = false;
                } else {
                    if (nejmensi > radaCisel[i]) {
                        nejmensi = radaCisel[i];
                        pocetOpakovani = 1;
                    } else if (nejmensi == radaCisel[i]) {
                        pocetOpakovani++;
                    }
                }
            }

            Console.WriteLine($"Nejmenší číslo je {nejmensi} a v řadě se opakuje {pocetOpakovani}×.");
        }
    }

    // 2) Zadejte řadu čísel ukončenou nulou. Potom zadáte číslo a program vypíše, kolikrát padlo.
    internal class E02HledaniCisla {
        public static void Mainx() {
            int zadaneCislo, hledaneCislo, celkemZadano = 0, pocetOpakovani = 0;
            int[] radaCisel = new int[99];
            int i = 0;

            do {
                Console.Write("Zadejte číslo [0 ukončí zadávání]: ");
                zadaneCislo = Convert.ToInt32(Console.ReadLine());
                radaCisel[i] = zadaneCislo;
                i++;
            } while (zadaneCislo != 0);
            celkemZadano = i - 1;

            Console.Write("Zadejte hledané číslo: ");
            hledaneCislo = Convert.ToInt32(Console.ReadLine());

            for (i = 0; i < celkemZadano; i++) {
                if (radaCisel[i] == hledaneCislo)
                    pocetOpakovani++;
            }

            Console.WriteLine($"Číslo {hledaneCislo} bylo zadáno {pocetOpakovani}×.");
        }
    }

    // 3) Vygenerujte několik hodů kostkou. Kolikrát padla jednotlivá čísla (%), jaký byl průměr?
    internal class E03KostkaStatistika {
        public static void Mainx() {
            Random rand = new Random();
            int pocetHodu = 20;
            int[] pole = new int[7];
            int soucet = 0;

            for (int i = 0; i < pocetHodu; i++) {
                int hod = rand.Next(1, 7);
                pole[hod]++;
                soucet += hod;
            }

            Console.WriteLine($"Výsledky po {pocetHodu} hodech:");
            for (int i = 1; i <= 6; i++) {
                Console.WriteLine($"  Číslo {i}: {pole[i]}× ({pole[i] * 100.0 / pocetHodu:F1} %)");
            }
            Console.WriteLine($"Průměr hodů: {(double)soucet / pocetHodu:F2}");
        }
    }

    // 4) Upravte program pro Sportku tak, aby se tažená čísla nemohla opakovat.
    internal class E04SportkaUnikatni {
        public static void Mainx() {
            Random rand = new Random();
            int[] tazena = new int[6];
            int pocet = 0;

            while (pocet < 6) {
                int nahodneCislo = rand.Next(1, 50);
                bool existuje = false;
                for (int j = 0; j < pocet; j++) {
                    if (tazena[j] == nahodneCislo) { existuje = true; break; }
                }
                if (!existuje) {
                    tazena[pocet] = nahodneCislo;
                    pocet++;
                }
            }

            Console.Write("Tažená čísla Sportky: ");
            for (int i = 0; i < 6; i++)
                Console.Write($"{tazena[i]}  ");
            Console.WriteLine();
        }
    }

    // 5) Zadejte řadu čísel. V oddělených cyklech spočítejte součet, průměr, max, min,
    // počet nenulových hodnot a součet druhých mocnin.
    internal class E05PoleOperace {
        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) { pole[pocet] = vstup; pocet++; }
            } while (vstup != 0);

            // Součet
            int soucet = 0;
            for (int i = 0; i < pocet; i++) soucet += pole[i];

            // Průměr
            double prumer = (double)soucet / pocet;

            // Maximum
            int max = pole[0];
            for (int i = 1; i < pocet; i++) if (pole[i] > max) max = pole[i];

            // Minimum
            int min = pole[0];
            for (int i = 1; i < pocet; i++) if (pole[i] < min) min = pole[i];

            // Počet nenulových (tu jsou všechny nenulové, ale pro úplnost)
            int nenulovych = 0;
            for (int i = 0; i < pocet; i++) if (pole[i] != 0) nenulovych++;

            // Součet druhých mocnin
            long soucetMocnin = 0;
            for (int i = 0; i < pocet; i++) soucetMocnin += (long)pole[i] * pole[i];

            Console.WriteLine($"Součet:              {soucet}");
            Console.WriteLine($"Průměr:              {prumer:F2}");
            Console.WriteLine($"Maximum:             {max}");
            Console.WriteLine($"Minimum:             {min}");
            Console.WriteLine($"Počet nenulových:    {nenulovych}");
            Console.WriteLine($"Součet mocnin (x²):  {soucetMocnin}");
        }
    }

    // 6) Zadejte postupně několik písmen. Program náhodně vygeneruje 10 slov po 5 znacích
    // složených z těchto písmen. Písmena se mohou opakovat.
    internal class E06NahodneSlovo {
        public static void Mainx() {
            char[] pismena = new char[99];
            int pocet = 0;
            string vstup;

            Console.WriteLine("Zadávejte písmena [prázdný řádek ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Console.ReadLine();
                if (vstup.Length > 0) {
                    pismena[pocet] = vstup[0];
                    pocet++;
                }
            } while (vstup.Length > 0 && pocet < 99);

            if (pocet == 0) { Console.WriteLine("Nebyla zadána žádná písmena."); return; }

            Random rand = new Random();
            Console.WriteLine("\n10 náhodně vygenerovaných slov:");
            for (int slovoIndex = 0; slovoIndex < 10; slovoIndex++) {
                for (int znakIndex = 0; znakIndex < 5; znakIndex++)
                    Console.Write(pismena[rand.Next(0, pocet)]);
                Console.WriteLine();
            }
        }
    }

    // 7) Zadejte postupně několik slov. Poté zadejte jedno z nich.
    // Program vypíše pořadí, na jakém bylo toto slovo zadáno.
    internal class E07HledaniSlova {
        public static void Mainx() {
            string[] slova = new string[99];
            int pocet = 0;
            string vstup;

            Console.WriteLine("Zadávejte slova [prázdný řádek ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Console.ReadLine();
                if (vstup.Length > 0) { slova[pocet] = vstup; pocet++; }
            } while (vstup.Length > 0 && pocet < 99);

            Console.Write("Zadejte hledané slovo: ");
            string hledane = Console.ReadLine();
            bool nalezeno = false;

            for (int i = 0; i < pocet; i++) {
                if (slova[i] == hledane) {
                    Console.WriteLine($"Slovo '{hledane}' bylo zadáno na pozici {i + 1}.");
                    nalezeno = true;
                }
            }
            if (!nalezeno) Console.WriteLine($"Slovo '{hledane}' nebylo nalezeno.");
        }
    }

    // 8) Řadu slov vypište v obráceném pořadí, pak pouze slova na sudých pozicích, pak na lichých.
    internal class E08SlovaObracene {
        public static void Mainx() {
            string[] slova = new string[99];
            int pocet = 0;
            string vstup;

            Console.WriteLine("Zadávejte slova [prázdný řádek ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Console.ReadLine();
                if (vstup.Length > 0) { slova[pocet] = vstup; pocet++; }
            } while (vstup.Length > 0 && pocet < 99);

            Console.Write("Obrácené pořadí: ");
            for (int i = pocet - 1; i >= 0; i--) Console.Write($"{slova[i]}  ");
            Console.WriteLine();

            Console.Write("Sudé pozice (2,4,...): ");
            for (int i = 1; i < pocet; i += 2) Console.Write($"{slova[i]}  ");
            Console.WriteLine();

            Console.Write("Liché pozice (1,3,...): ");
            for (int i = 0; i < pocet; i += 2) Console.Write($"{slova[i]}  ");
            Console.WriteLine();
        }
    }
}

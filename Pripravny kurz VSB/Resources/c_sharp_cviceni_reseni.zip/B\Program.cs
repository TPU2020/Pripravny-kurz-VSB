﻿namespace B {
    internal class Program {
        static void Main(string[] args) {
            Console.WriteLine("Vyber program:");
            Console.WriteLine(" 1 - Nerovnost x+3<5y-1");
            Console.WriteLine(" 2 - Dělitelnost x a y");
            Console.WriteLine(" 3 - Platnost výrazu 1/(x*y).");
            Console.WriteLine(" 4 - Min max 3 čísla");
            Console.WriteLine(" 5 - Porovnání výšky žáků");
            Console.WriteLine(" 6 - Které auto je rychlejší");
            Console.WriteLine(" 7 - Letopočet éra");
            Console.WriteLine(" 8 - Urči znak");
            Console.WriteLine(" 9 - Větší, nebo menší číslo");
            Console.WriteLine("10 - Odmocnina čísla");
            Console.WriteLine("11 - Čtverec či obdélník?");
            Console.WriteLine("12 - Je či není horko?");
            Console.WriteLine("13 - Kvadratická rovnice");
            Console.WriteLine("14 - Chceš skončit?");
            Console.WriteLine("15 - Jaké je počasí");
            Console.WriteLine("16 - Aritmetika");
            Console.WriteLine("17 - Převod měny");
            Console.WriteLine("18 - Kolik dní má měsíc");
            Console.Write("Zadej číslo volby: ");

            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1:
                    B01Nerovnost.Mainx();
                    break;
                case 2:
                    B02Delitelnost.Mainx();
                    break;
                case 3:
                    B03VyrazDeleni.Mainx();
                    break;
                case 4:
                    B04MaxMin.Mainx();
                    break;
                case 5:
                    B05VyskaZaka.Mainx();
                    break;
                case 6:
                    B06Auta.Mainx();
                    break;
                case 7:
                    B07Letopocet.Mainx();
                    break;
                case 8:
                    B08CharOrNumber.Mainx();
                    break;
                case 9:
                    B09VetsiMensi.Mainx();
                    break;
                case 10:
                    B10Odmocnina.Mainx();
                    break;
                case 11:
                    B11CtverecObdelnik.Mainx();
                    break;
                case 12:
                    B12JeNeniHorko.Mainx();
                    break;
                case 13:
                    B13KvadratickaRovnice.Mainx();
                    break;
                case 14:
                    B14ChcesKonec.Mainx();
                    break;
                case 15:
                    B15PocasiCase.Mainx();
                    break;
                case 16:
                    B16Aritmetika.Mainx();
                    break;
                case 17:
                    B17PrevodMeny.Mainx();
                    break;
                case 18:
                    B18MesicKolikDni.Mainx();
                    break;
                default:
                    Console.WriteLine("Neplatná volba!");
                    break;
            }
        }
    }
    // 1) Určete, zda dvě zadaná čísla x,y čísla splňují nerovnost x+3<5y-1
    internal class B01Nerovnost {
        public static void Mainx() {
            double x, y;
            Console.WriteLine("Porovnání zda zadaná čísla splňují nerovnost x+3<5y-1");
            Console.WriteLine("Zadejte číslo x ");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej číslo y: ");
            y = Convert.ToDouble(Console.ReadLine());
            if ((x + 3) < (5 * y - 1)) {
                Console.WriteLine($"Zadaná čísla splňují nerovnost {x + 3} < {5 * y - 1}");
            }
            else {
                Console.WriteLine($"Zadaná čísla nesplňují nerovnost: {x + 3} < {5 * y - 1}");
            }
        }
    }
    // 2) Zadejte dvě čísla x a y. Zjistěte, zda číslo x je dělitelné číslem y.
    internal class B02Delitelnost {
        public static void Mainx() {
            double x, y;
            Console.WriteLine("Porovnání zda číslo x je dělitelné y");
            Console.WriteLine("Zadejte číslo x ");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej číslo y: ");
            y = Convert.ToDouble(Console.ReadLine());
            if (y == 0) {
                Console.WriteLine("Nelze dělit nulou!");
            }
            else if (x % y == 0) {
                Console.WriteLine("Číslo x je dělitelné y");
            }
            else {
                Console.WriteLine("Číslo x není dělitelné y");
            }
        }
    }
    // 3) Pro danou dvojici čísel x,y spočítejte hodnotu výrazu 1/(x.y).
    // Pokud by byl jmenovatel nulový, tak nepočítá, ale vypíše varovné hlášení.
    internal class B03VyrazDeleni {
        public static void Mainx() {
            double x, y, vysledek;
            Console.WriteLine("Spočítá hodnotu výrazu 1/(x.y).");
            Console.WriteLine("Zadejte číslo x ");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadej číslo y: ");
            y = Convert.ToDouble(Console.ReadLine());
            if (x * y == 0) {
                Console.WriteLine("Nelze dělit nulou!");
            }
            else {
                vysledek = 1 / (x * y);
                Console.WriteLine($"Výraz je platný, výsledek je: {vysledek}");
            }
        }
    }
    // 4) Zadejte tři čísla, počítač zjistí, které je největší a které nejmenší.
    internal class B04MaxMin {
        public static void Mainx() {
            double dalsiCislo, max, min;
            Console.WriteLine("Zadejte tři čísla:");
            min = max = Convert.ToDouble(Console.ReadLine());
            dalsiCislo = Convert.ToDouble(Console.ReadLine());

            if (min > dalsiCislo) {
                min = dalsiCislo;
            }
            else {
                max = dalsiCislo;
            }

            dalsiCislo = Convert.ToDouble(Console.ReadLine());

            if (dalsiCislo < min) {
                min = dalsiCislo;
            }
            else if (dalsiCislo > max) {
                max = dalsiCislo;
            }
            Console.WriteLine($"Minimum je: {min}, maximum je: {max}");
        }
    }
    // 5) Sestavte program, který postupně načte jméno a výšku prvního žáka, a jméno a výšku druhého žáka.
    // Poté zobrazí jméno vyššího z nich.
    internal class B05VyskaZaka {
        public static void Mainx() {
            string jmenoA, jmenoB;
            double vyskaA, vyskaB;
            Console.WriteLine("Který ze dvou žáků je vyšší");
            Console.Write("Zadejte jméno žáka A: ");
            jmenoA = Console.ReadLine();
            Console.Write("Zadejte výšku žáka A [cm]: ");
            vyskaA = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zadejte jméno žáka B: ");
            jmenoB = Console.ReadLine();
            Console.Write("Zadejte výšku žáka B [cm]: ");
            vyskaB = Convert.ToDouble(Console.ReadLine());
            if (vyskaA > vyskaB) {
                Console.WriteLine($"Vyšší žák je {jmenoA} ({vyskaA} cm).");
            }
            else if (vyskaB > vyskaA) {
                Console.WriteLine($"Vyšší žák je {jmenoB} ({vyskaB} cm).");
            }
            else {
                Console.WriteLine($"{jmenoA} a {jmenoB} jsou stejně vysocí ({vyskaA} cm).");
            }
        }
    }
    // 6) První auto ujelo trasu S1 za čas T1 a druhé trasu S2 za čas T2. (údaje zadejte).
    // Spočítejte průměrnou rychlost obou aut a vypište zprávu "... auto je o ... rychlejší".
    internal class B06Auta {
        public static void Mainx() {
            double draha1, cas1, rychlost1, draha2, cas2, rychlost2;
            Console.WriteLine("Které auto je rychlejší");
            Console.WriteLine("Zadejte vzdálenost S1 [km]: ");
            draha1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte čas T1 [hod]: ");
            cas1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte vzdálenost S2 [km]: ");
            draha2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Zadejte čas T2 [hod]: ");
            cas2 = Convert.ToDouble(Console.ReadLine());
            rychlost1 = draha1 / cas1;
            rychlost2 = draha2 / cas2;
            if (rychlost1 > rychlost2) {
                Console.WriteLine($"Auto 1 je o {rychlost1 - rychlost2} km/h rychlejší");
            }
            else if (rychlost2 > rychlost1) {
                Console.WriteLine($"Auto 2 je o {rychlost2 - rychlost1} km/h rychlejší");
            }
            else {
                Console.WriteLine("Obě auta jela stejnou průměrnou rychlostí.");
            }
        }
    }
    // 7) Uživatel zadá letopočet (od roku 1600).
    // Program vrátí název státního útvaru, ve kterém jsme se tehdy nacházeli (Rakousko,
    // Rakousko-Uhersko, Československá republika, Protektorát Böhmen und Mähren atd.). Řešte pomocí else if.
    internal class B07Letopocet {
        public static void Mainx() {
            int rok;
            Console.WriteLine("Zadejte letopočet (od roku 1600): ");
            rok = Convert.ToInt32(Console.ReadLine());

            if (rok < 1600) {
                Console.WriteLine("Letopočet musí být od roku 1600.");
            }
            else if (rok >= 1600 && rok < 1867) {
                Console.WriteLine($"V roce {rok} jsme byli součástí Rakouska.");
            }
            else if (rok >= 1867 && rok < 1918) {
                Console.WriteLine($"V roce {rok} jsme byli součástí Rakousko-Uherska.");
            }
            else if (rok >= 1918 && rok < 1939) {
                Console.WriteLine($"V roce {rok} jsme byli součástí Československé republiky.");
            }
            else if (rok >= 1939 && rok < 1945) {
                Console.WriteLine($"V roce {rok} jsme byli součástí Protektorátu Čechy a Morava.");
            }
            else if (rok >= 1945 && rok < 1993) {
                Console.WriteLine($"V roce {rok} jsme byli součástí Československa.");
            }
            else if (rok >= 1993) {
                Console.WriteLine("Od roku 1993 jsme Česká republika.");
            }

        }
    }
    // 8) Uživatel zadá znak, program odpoví, zda se jedná o písmeno, číslici nebo jiný znak. Řešte pomocí else if.
    internal class B08CharOrNumber {
        public static void Mainx() {
            char znak;
            Console.WriteLine("Zadej znak: ");
            znak = Convert.ToChar(Console.ReadLine());

            if ((int)znak >= 48 && (int)znak <= 57) { Console.WriteLine($"{znak} - Toto je číslice"); }
            else if ((int)znak >= 97 && (int)znak <= 122) { Console.WriteLine($"{znak} - Toto je malé písmeno"); }
            else if ((int)znak >= 65 && (int)znak <= 90) { Console.WriteLine($"{znak} - Toto je velké písmeno"); }
            else { Console.WriteLine($"{znak} - Toto je jiný znak"); }
        }
    }
    // 9) Zadejte dvě čísla, počítač napíše "První číslo je větší (nebo menší)"
    internal class B09VetsiMensi {
        public static void Mainx() {
            double numeroUno, numeroDue;

            Console.WriteLine("Zadejte číslo jedna:");
            numeroUno = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Zadejte číslo dvě");
            numeroDue = Convert.ToDouble(Console.ReadLine());

            if (numeroUno < numeroDue) { Console.WriteLine("První číslo je menší."); }
            else if (numeroUno > numeroDue) { Console.WriteLine("První číslo je větší"); }
            else { Console.WriteLine("Čísla jsou stejně velká"); }
        }
    }
    // 10) Zadejte číslo. Počítač vypíše: "Odmocnina čísla ... je ..." nebo oznámí, že odmocninu záporného čísla počítat nebude.
    internal class B10Odmocnina {
        public static void Mainx() {
            double cislo;

            Console.WriteLine("Zadejte číslo: ");
            cislo = Convert.ToDouble(Console.ReadLine());

            if (cislo >= 0) {
                Console.WriteLine($"Odmocnina čísla {cislo} je: {Math.Sqrt(cislo)}");
            }
            else { Console.WriteLine("Odmocninu záporného čísla počítat nebudu"); }
        }
    }
    // 11) Zadejte dvě kladná čísla, která představují délky stran obdélníka.
    // Zjistěte, zda se jedná o čtverec a vytiskněte zprávu ve tvaru:
    // "Čtverec má dálku strany..." nebo "Obdélník má rozměry ... x ..."
    internal class B11CtverecObdelnik {
        public static void Mainx() {
            int a, b;

            Console.WriteLine("Zadejte stranu a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Zadejte stranu b:");
            b = Convert.ToInt32(Console.ReadLine());

            if (a == b) { Console.WriteLine($"Čtverec má délku strany {a}"); }
            else { Console.WriteLine($"Obdélník má rozměry {a} x {b}"); }
        }
    }
    // 12) Program se zeptá, zda je den a zda je horko (odpověď a/n).
    // Pouze v případě obou odpovědí kladných vám navrhne jít si zaplavat.
    // Použijte jen jeden příkaz IF(ale se složenou podmínkou).
    //  na rozdíl od obdobného příkladu v BasicCv.docuvažujte tentokrát i případ,
    //  že by uživatel omylem zadal odpověď na první či druhý dotaz velkým písmenem.
    internal class B12JeNeniHorko {
        public static void Mainx() {
            char den, horko;

            Console.WriteLine("Je den? [aA/nN]");
            den = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Je horko? [aA/nN");
            horko = Convert.ToChar(Console.ReadLine());

            if ((den == 'A' || den == 'a') && (horko == 'A' || horko == 'a')) {
                Console.WriteLine("Běž si zaplavat");
            }
            else {
                Console.WriteLine("Radši zůstaň doma");
            }

        }
    }
    // 13) Zadejte a, b, c. Program vypočte kořeny kvadratické rovnice a·x² + b·x + c = 0.
    internal class B13KvadratickaRovnice {
        public static void Mainx() {
            double a, b, c;
            Console.Write("Zadejte a: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zadejte b: ");
            b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zadejte c: ");
            c = Convert.ToDouble(Console.ReadLine());

            if (a == 0) {
                Console.WriteLine("Není kvadratická rovnice (a = 0).");
                return;
            }
            double diskriminant = b * b - 4 * a * c;
            if (diskriminant > 0) {
                double x1 = (-b + Math.Sqrt(diskriminant)) / (2 * a);
                double x2 = (-b - Math.Sqrt(diskriminant)) / (2 * a);
                Console.WriteLine($"Dva reálné kořeny: x1 = {x1:F4}, x2 = {x2:F4}");
            }
            else if (diskriminant == 0) {
                double x = -b / (2 * a);
                Console.WriteLine($"Jeden dvojnásobný kořen: x = {x:F4}");
            }
            else {
                Console.WriteLine("Rovnice nemá reálné kořeny (diskriminant < 0).");
            }
        }
    }
    // 14) Počítač se zeptá: "Chcete skončit? (A/N)"
    // Při stisku A program skončí, při stisku čehokoliv jiného se vypíše "A stejně skončím!" a program skončí.
    internal class B14ChcesKonec {
        public static void Mainx() {
            char konec;
            Console.WriteLine("Chceš skončit? (A/N)");
            konec = Convert.ToChar(Console.ReadLine());

            if (konec != 'A' && konec != 'a') {
                Console.WriteLine("A stejně skončím!");
            }
        }
    }
    // 15) Program se zeptá, jak je venku, nabídne vám: úmorné vedro, zima, déšť, mlha, tma, chumelenice, atd.
    // Podle toho vám     navrhne, co máte dělat, např.dobře se obléci, jít na plovárnu atd.Nepoužívejte příkaz IF.
    internal class B15PocasiCase {
        public static void Mainx() {
            Console.WriteLine("Jak je venku?:");
            Console.WriteLine(" 1 - Horko");
            Console.WriteLine(" 2 - Zima");
            Console.WriteLine(" 3 - Déšť");
            Console.WriteLine(" 4 - Mlha");
            Console.WriteLine(" 5 - Tma ");
            Console.WriteLine(" 6 - Chumelenice");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1:
                    Console.WriteLine("Běž plavat");
                    break;
                case 2:
                    Console.WriteLine("Vem si kabát");
                    break;
                case 3:
                    Console.WriteLine("Nezapomeň deštník");
                    break;
                case 4:
                    Console.WriteLine("Zapni si mlhovky v autě");
                    break;
                case 5:
                    Console.WriteLine("Dívej se pod nohy");
                    break;
                case 6:
                    Console.WriteLine("Radši nikam nechoď");
                    break;
                default:
                    Console.WriteLine("Neplatná volba!");
                    break;
            }

        }
    }
    // 16) Uživatel zadá dvě čísla. Poté se objeví nabídka, zda chce sčítat, odčítat, násobit, dělit nebo končit.
    // Poté se objeví výsledek vybrané operace se zadanými čísly nebo program skončí.
    internal class B16Aritmetika {
        public static void Mainx() {
            double x, y;

            Console.WriteLine("Zadejte číslo x: ");
            x = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Zadejte číslo y: ");
            y = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Vyberte aritmetickou operaci. (nejsou ošetřené nesmysly)");
            Console.WriteLine(" 1 - Sčítání");
            Console.WriteLine(" 2 - Odčítání");
            Console.WriteLine(" 3 - Násobení");
            Console.WriteLine(" 4 - Dělení");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1:
                    Console.WriteLine($"Výsledek sčítání x+y={x + y}");
                    break;
                case 2:
                    Console.WriteLine($"Výsledek odečítání x-y={x - y}");
                    break;
                case 3:
                    Console.WriteLine($"Výsledek násobení x*y={x * y}");
                    break;
                case 4:
                    Console.WriteLine($"Výsledek dělení x/y={x / y}");
                    break;
                default:
                    Console.WriteLine("Neplatná volba!");
                    break;
            }

        }
    }
    // 17) Zadejte částku v Kč a pak si z nabídky vyberte měnu, na kterou chcete směnit (např. DEM, USD, FRF atd.).
    // Počítač přepočítá částku na tuto měnu.
    internal class B17PrevodMeny {
        public static void Mainx() {
            double castka;
            String volba;
            Console.WriteLine("Zadej částku k převodu");
            castka = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Na jakou měnu chceš převést? [DEM,USD,FRF]");

            volba = Console.ReadLine().ToUpper();
            switch (volba) {
                case "DEM":
                    Console.WriteLine(castka * 25);
                    break;
                case "USD":
                    Console.WriteLine(castka * 22);
                    break;
                case "FRF":
                    Console.WriteLine(castka * 17);
                    break;
                default:
                    Console.WriteLine("Neplatná volba");
                    break;

            }
        }
    }

    internal class B18MesicKolikDni {
        public static void Mainx() {
            Console.WriteLine("Zadejte číslo měsíce");
            byte mesic = Convert.ToByte(Console.ReadLine());

            switch (mesic) {
                case 1:
                    Console.WriteLine("Měsíc leden má 31 dní");
                    break;
                case 2:
                    Console.WriteLine("Měsíc únor má 28 dní");
                    break;
                case 3:
                    Console.WriteLine("Měsíc březen má 31 dní");
                    break;
                case 4:
                    Console.WriteLine("Měsíc duben má 30 dní");
                    break;
                case 5:
                    Console.WriteLine("Měsíc květen má 31 dní");
                    break;
                case 6:
                    Console.WriteLine("Měsíc červen má 30 dní");
                    break;
                case 7:
                    Console.WriteLine("Měsíc červenec má 31 dní");
                    break;
                case 8:
                    Console.WriteLine("Měsíc srpen má 31 dní");
                    break;
                case 9:
                    Console.WriteLine("Měsíc září má 30 dní");
                    break;
                case 10:
                    Console.WriteLine("Měsíc říjen má 31 dní");
                    break;
                case 11:
                    Console.WriteLine("Měsíc listopad má 30 dní");
                    break;
                case 12:
                    Console.WriteLine("Měsíc prosinec má 31 dní");
                    break;
                default:
                    Console.WriteLine("Neplatná volba");
                    break;
            }
        }
    }
}
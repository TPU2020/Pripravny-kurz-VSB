namespace F {
    internal class Program {
        static void Main(string[] args) {
            Console.WriteLine("Vyber program:");
            Console.WriteLine("--- f1) Funkce bez pole ---");
            Console.WriteLine(" 1 - Stupně a minuty na radiány");
            Console.WriteLine(" 2 - ASCII hodnota znaku");
            Console.WriteLine(" 3 - Šifrovací funkce (posun v abecedě)");
            Console.WriteLine(" 4 - Přestupný rok");
            Console.WriteLine(" 5 - Kurz měny");
            Console.WriteLine(" 6 - Den v týdnu");
            Console.WriteLine(" 7 - Typ znaku (písmeno/číslice/ostatní)");
            Console.WriteLine(" 8 - Počet dní měsíce");
            Console.WriteLine(" 9 - Obrácení textu");
            Console.WriteLine("10 - Text bez mezer");
            Console.WriteLine("11 - Počet výskytů podřetězce");
            Console.WriteLine("12 - Číslo dne v roce");
            Console.WriteLine("--- f2) Funkce s polem ---");
            Console.WriteLine("13 - Úroky na poli");
            Console.WriteLine("14 - Sazka bez opakování");
            Console.WriteLine("15 - Tisk řádku N znaků Z (subrutina)");
            Console.WriteLine("16 - Počet výskytů čísla v poli");
            Console.WriteLine("17 - Statistika hodů kostkou");
            Console.WriteLine("18 - Sudá čísla z pole");
            Console.WriteLine("19 - Je pole vzestupné?");
            Console.WriteLine("20 - Index prvku porušujícího vzestupnost");
            Console.WriteLine("21 - Je pole lineární posloupností?");
            Console.WriteLine("22 - Seřazené pole (bubble sort)");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba) {
                case 1:  F01StupneNaRadiany.Mainx();    break;
                case 2:  F02AsciiHodnota.Mainx();        break;
                case 3:  F03Sifrovani.Mainx();            break;
                case 4:  F04PrestupnyRok.Mainx();        break;
                case 5:  F05KurzMeny.Mainx();            break;
                case 6:  F06DenVTydnu.Mainx();          break;
                case 7:  F07TypZnaku.Mainx();            break;
                case 8:  F08DniMesice.Mainx();           break;
                case 9:  F09ObratText.Mainx();           break;
                case 10: F10BezMezer.Mainx();            break;
                case 11: F11Vyskyty.Mainx();              break;
                case 12: F12CisloDneVRoce.Mainx();     break;
                case 13: F13UrokyPole.Mainx();           break;
                case 14: F14SazkaBezOpakovani.Mainx();  break;
                case 15: F15TiskRadku.Mainx();           break;
                case 16: F16PocetVyskytuPole.Mainx();   break;
                case 17: F17StatistikaKostky.Mainx();    break;
                case 18: F18SudaCislaZPole.Mainx();    break;
                case 19: F19JeVzestupne.Mainx();         break;
                case 20: F20IndexPoruseni.Mainx();       break;
                case 21: F21JeLinearni.Mainx();          break;
                case 22: F22SerazenePole.Mainx();        break;
                default: Console.WriteLine("Neplatná volba!"); break;
            }
        }
    }

    // =====================================================================
    // f1) FUNKCE BEZ POLE
    // =====================================================================

    // 1) Funkce převádí stupně a minuty na radiány (trojčlenkou).
    internal class F01StupneNaRadiany {
        static double StupneNaRadian(double stupne, double minuty) {
            double celkoveStupne = stupne + minuty / 60.0;
            return celkoveStupne * Math.PI / 180.0;
        }

        public static void Mainx() {
            Console.Write("Zadejte stupně: ");
            double stupne = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zadejte minuty: ");
            double minuty = Convert.ToDouble(Console.ReadLine());

            double radiany = StupneNaRadian(stupne, minuty);
            Console.WriteLine($"{stupne}° {minuty}' = {radiany:F6} rad");
        }
    }

    // 2) Funkce, které se zadá znak a která vrátí jeho ASCII hodnotu.
    internal class F02AsciiHodnota {
        static int ZnakNaAscii(char znak) {
            return (int)znak;
        }

        public static void Mainx() {
            Console.Write("Zadejte znak: ");
            char znak = Convert.ToChar(Console.ReadLine());

            int ascii = ZnakNaAscii(znak);
            Console.WriteLine($"ASCII hodnota znaku '{znak}' je: {ascii}");
        }
    }

    // 3) Šifrovací funkce – posune znak o n pozic v ASCII (pro 'z' vrátí 'a').
    internal class F03Sifrovani {
        static char PosunZnak(char znak, int n) {
            if (znak >= 'a' && znak <= 'z') {
                return (char)('a' + (znak - 'a' + n) % 26);
            }
            if (znak >= 'A' && znak <= 'Z') {
                return (char)('A' + (znak - 'A' + n) % 26);
            }
            return znak;
        }

        public static void Mainx() {
            Console.Write("Zadejte znak: ");
            char znak = Convert.ToChar(Console.ReadLine());
            Console.Write("Zadejte posun n: ");
            int n = Convert.ToInt32(Console.ReadLine());

            char vysledek = PosunZnak(znak, n);
            Console.WriteLine($"Znak '{znak}' posunutý o {n} = '{vysledek}'");
        }
    }

    // 4) Funkce vrací true, pokud je rok přestupný (Gregoriánský kalendář).
    internal class F04PrestupnyRok {
        static bool JePrestupny(int rok) {
            if (rok % 400 == 0) return true;
            if (rok % 100 == 0) return false;
            return rok % 4 == 0;
        }

        public static void Mainx() {
            Console.Write("Zadejte rok: ");
            int rok = Convert.ToInt32(Console.ReadLine());

            if (JePrestupny(rok))
                Console.WriteLine($"Rok {rok} je přestupný.");
            else
                Console.WriteLine($"Rok {rok} není přestupný.");
        }
    }

    // 5) Funkce Kurs – převede koruny na zadanou měnu. Vrátí -1 pro neznámou měnu.
    internal class F05KurzMeny {
        static double Kurs(double koruny, string mena) {
            switch (mena.ToUpper()) {
                case "EUR": return koruny / 25.0;
                case "USD": return koruny / 22.0;
                case "GBP": return koruny / 30.0;
                default:    return -1;
            }
        }

        public static void Mainx() {
            Console.Write("Zadejte částku v Kč: ");
            double koruny = Convert.ToDouble(Console.ReadLine());
            Console.Write("Zadejte kód měny (EUR, USD, GBP): ");
            string mena = Console.ReadLine();

            double vysledek = Kurs(koruny, mena);
            if (vysledek == -1)
                Console.WriteLine("Neznámá měna.");
            else
                Console.WriteLine($"{koruny} Kč = {vysledek:F2} {mena.ToUpper()}");
        }
    }

    // 6) Funkce, které se předá číslo 1–7 a vrací slovně den v týdnu.
    internal class F06DenVTydnu {
        static string DenVTydnu(int cislo) {
            switch (cislo) {
                case 1: return "Pondělí";
                case 2: return "Úterý";
                case 3: return "Středa";
                case 4: return "Čtvrtek";
                case 5: return "Pátek";
                case 6: return "Sobota";
                case 7: return "Neděle";
                default: return "Neplatný den";
            }
        }

        public static void Mainx() {
            Console.Write("Zadejte číslo dne (1–7): ");
            int cislo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Den číslo {cislo} je: {DenVTydnu(cislo)}");
        }
    }

    // 7) Obdoba signum – funkce vrátí typ znaku: písmeno, číslice, ostatní.
    internal class F07TypZnaku {
        static string TypZnaku(char znak) {
            if ((znak >= 'a' && znak <= 'z') || (znak >= 'A' && znak <= 'Z'))
                return "písmeno";
            if (znak >= '0' && znak <= '9')
                return "číslice";
            return "ostatní";
        }

        public static void Mainx() {
            Console.Write("Zadejte znak: ");
            char znak = Convert.ToChar(Console.ReadLine());

            Console.WriteLine($"Znak '{znak}' je: {TypZnaku(znak)}");
        }
    }

    // 8) Funkce PocetDniMesice – vrátí počet dní měsíce, nebo -1 pro neplatný měsíc.
    internal class F08DniMesice {
        static int PocetDniMesice(int mesic) {
            switch (mesic) {
                case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                    return 31;
                case 4: case 6: case 9: case 11:
                    return 30;
                case 2:
                    return 28;
                default:
                    return -1;
            }
        }

        public static void Mainx() {
            Console.Write("Zadejte číslo měsíce: ");
            int mesic = Convert.ToInt32(Console.ReadLine());

            int dni = PocetDniMesice(mesic);
            if (dni == -1)
                Console.WriteLine("Neplatné číslo měsíce.");
            else
                Console.WriteLine($"Měsíc {mesic} má {dni} dní.");
        }
    }

    // 9) Funkce ObratText – vrátí řetězec se znaky v obráceném pořadí.
    internal class F09ObratText {
        static string ObratText(string text) {
            string obraceny = "";
            for (int i = text.Length - 1; i >= 0; i--) {
                obraceny += text[i];
            }
            return obraceny;
        }

        public static void Mainx() {
            Console.Write("Zadejte text: ");
            string text = Console.ReadLine();

            Console.WriteLine($"Obrácený text: {ObratText(text)}");
        }
    }

    // 10) Funkce BezMezer – vrátí řetězec bez mezer.
    internal class F10BezMezer {
        static string BezMezer(string text) {
            string vysledek = "";
            for (int i = 0; i < text.Length; i++) {
                if (text[i] != ' ')
                    vysledek += text[i];
            }
            return vysledek;
        }

        public static void Mainx() {
            Console.Write("Zadejte text: ");
            string text = Console.ReadLine();

            Console.WriteLine($"Text bez mezer: {BezMezer(text)}");
        }
    }

    // 11) Funkce Vyskyty – vrátí počet výskytů podřetězce v řetězci.
    internal class F11Vyskyty {
        static int Vyskyty(string text, string podretezec) {
            int pocet = 0;
            int pozice = 0;
            while ((pozice = text.IndexOf(podretezec, pozice)) != -1) {
                pocet++;
                pozice++;
            }
            return pocet;
        }

        public static void Mainx() {
            Console.Write("Zadejte text: ");
            string text = Console.ReadLine();
            Console.Write("Zadejte hledaný podřetězec: ");
            string podretezec = Console.ReadLine();

            int pocet = Vyskyty(text, podretezec);
            Console.WriteLine($"Podřetězec '{podretezec}' se vyskytuje {pocet}×.");
        }
    }

    // 12) Funkce CisloDneVRoce – vrátí pořadové číslo dne v roce, nebo -1 pro neplatné datum.
    internal class F12CisloDneVRoce {
        static bool JePrestupny(int rok) {
            if (rok % 400 == 0) return true;
            if (rok % 100 == 0) return false;
            return rok % 4 == 0;
        }

        static int PocetDniMesice(int mesic, int rok) {
            switch (mesic) {
                case 1: case 3: case 5: case 7: case 8: case 10: case 12: return 31;
                case 4: case 6: case 9: case 11: return 30;
                case 2: return JePrestupny(rok) ? 29 : 28;
                default: return -1;
            }
        }

        static int CisloDneVRoce(int den, int mesic, int rok) {
            if (mesic < 1 || mesic > 12) return -1;
            int maxDni = PocetDniMesice(mesic, rok);
            if (den < 1 || den > maxDni) return -1;

            int soucet = 0;
            for (int m = 1; m < mesic; m++) {
                soucet += PocetDniMesice(m, rok);
            }
            return soucet + den;
        }

        public static void Mainx() {
            Console.Write("Zadejte den: ");
            int den = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zadejte měsíc: ");
            int mesic = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zadejte rok: ");
            int rok = Convert.ToInt32(Console.ReadLine());

            int cislo = CisloDneVRoce(den, mesic, rok);
            if (cislo == -1)
                Console.WriteLine("Neplatné datum.");
            else
                Console.WriteLine($"{den}.{mesic}.{rok} je {cislo}. den v roce.");
        }
    }

    // =====================================================================
    // f2) FUNKCE S POLEM
    // =====================================================================

    // 13) Funkce dostane pole úspor a úrokovou míru, vrátí pole po přičtení úroků.
    internal class F13UrokyPole {
        static double[] PripoctiUroky(double[] uspora, double urok) {
            double[] vysledek = new double[uspora.Length];
            for (int i = 0; i < uspora.Length; i++) {
                vysledek[i] = uspora[i] + uspora[i] * urok / 100.0;
            }
            return vysledek;
        }

        public static void Mainx() {
            double[] uspora = new double[99];
            int pocet = 0;
            double vstup;

            Console.WriteLine("Zadávejte úspory osob [0 ukončí]:");
            do {
                Console.Write($"  Osoba {pocet + 1}: ");
                vstup = Convert.ToDouble(Console.ReadLine());
                if (vstup != 0) {
                    uspora[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            Console.Write("Zadejte roční úrokovou míru [%]: ");
            double urok = Convert.ToDouble(Console.ReadLine());

            double[] usporaTemp = new double[pocet];
            for (int i = 0; i < pocet; i++) usporaTemp[i] = uspora[i];

            double[] vysledek = PripoctiUroky(usporaTemp, urok);

            Console.WriteLine("\nÚspory po úrocích:");
            for (int i = 0; i < pocet; i++) {
                Console.WriteLine($"  Osoba {i + 1}: {uspora[i]:F2} Kč → {vysledek[i]:F2} Kč");
            }
        }
    }

    // 14) Funkce dostane pole čísel Sazky (mohou se opakovat), vrátí pole bez duplikátů.
    internal class F14SazkaBezOpakovani {
        static int[] OdstranDuplikaty(int[] cisla, int pocet) {
            int[] unikatni = new int[pocet];
            int pocetUnikatnich = 0;

            for (int i = 0; i < pocet; i++) {
                bool jizExistuje = false;
                for (int j = 0; j < pocetUnikatnich; j++) {
                    if (unikatni[j] == cisla[i]) {
                        jizExistuje = true;
                        break;
                    }
                }
                if (!jizExistuje) {
                    unikatni[pocetUnikatnich] = cisla[i];
                    pocetUnikatnich++;
                }
            }

            int[] vysledek = new int[pocetUnikatnich];
            for (int i = 0; i < pocetUnikatnich; i++) vysledek[i] = unikatni[i];
            return vysledek;
        }

        public static void Mainx() {
            Random rand = new Random();
            int[] tazena = new int[10];
            Console.WriteLine("Tažená čísla Sazky (mohou se opakovat):");
            for (int i = 0; i < 10; i++) {
                tazena[i] = rand.Next(1, 50);
                Console.Write($"{tazena[i]}  ");
            }
            Console.WriteLine();

            int[] ocistena = OdstranDuplikaty(tazena, 10);

            Console.Write("Po odstranění duplikátů: ");
            for (int i = 0; i < ocistena.Length; i++) {
                Console.Write($"{ocistena[i]}  ");
            }
            Console.WriteLine();
        }
    }

    // 15) Subrutina – vytiskne řádek N znaků Z.
    internal class F15TiskRadku {
        static void TiskRadku(int n, char z) {
            for (int i = 0; i < n; i++) {
                Console.Write(z);
            }
            Console.WriteLine();
        }

        public static void Mainx() {
            Console.Write("Zadejte počet znaků N: ");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zadejte znak Z: ");
            char z = Convert.ToChar(Console.ReadLine());

            TiskRadku(n, z);
        }
    }

    // 16) Funkce PocetVyskytu – vrátí, kolikrát se číslo C vyskytuje v poli A.
    internal class F16PocetVyskytuPole {
        static int PocetVyskytu(int[] pole, int pocet, int c) {
            int vyskyty = 0;
            for (int i = 0; i < pocet; i++) {
                if (pole[i] == c) vyskyty++;
            }
            return vyskyty;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            Console.Write("Zadejte hledané číslo C: ");
            int c = Convert.ToInt32(Console.ReadLine());

            int vyskyty = PocetVyskytu(pole, pocet, c);
            Console.WriteLine($"Číslo {c} se v poli vyskytuje {vyskyty}×.");
        }
    }

    // 17) Funkce PocetPadlych – dostane počet hodů, vrátí pole s četnostmi hodnot 1–6.
    internal class F17StatistikaKostky {
        static int[] PocetPadlych(int pocetHodu) {
            Random rand = new Random();
            int[] cetnosti = new int[7];
            for (int i = 0; i < pocetHodu; i++) {
                int hod = rand.Next(1, 7);
                cetnosti[hod]++;
            }
            return cetnosti;
        }

        public static void Mainx() {
            Console.Write("Zadejte počet hodů kostkou: ");
            int pocetHodu = Convert.ToInt32(Console.ReadLine());

            int[] cetnosti = PocetPadlych(pocetHodu);

            Console.WriteLine($"\nVýsledky po {pocetHodu} hodech:");
            for (int i = 1; i <= 6; i++) {
                Console.WriteLine($"  Číslo {i}: {cetnosti[i]}× ({cetnosti[i] * 100.0 / pocetHodu:F1} %)");
            }
        }
    }

    // 18) Funkce SudaCislaZPole – vrátí pole obsahující jen sudá čísla z předaného pole.
    internal class F18SudaCislaZPole {
        static int[] SudaCislaZPole(int[] pole, int pocet) {
            int[] suda = new int[pocet];
            int pocetSudych = 0;
            for (int i = 0; i < pocet; i++) {
                if (pole[i] % 2 == 0) {
                    suda[pocetSudych] = pole[i];
                    pocetSudych++;
                }
            }
            int[] vysledek = new int[pocetSudych];
            for (int i = 0; i < pocetSudych; i++) vysledek[i] = suda[i];
            return vysledek;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            int[] poleProcopy = new int[pocet];
            for (int i = 0; i < pocet; i++) poleProcopy[i] = pole[i];

            int[] suda = SudaCislaZPole(poleProcopy, pocet);

            Console.Write("Sudá čísla: ");
            for (int i = 0; i < suda.Length; i++) Console.Write($"{suda[i]}  ");
            Console.WriteLine();
        }
    }

    // 19) Funkce – vrátí true, pokud je pole seřazeno vzestupně.
    internal class F19JeVzestupne {
        static bool JeVzestupne(int[] pole, int pocet) {
            for (int i = 0; i < pocet - 1; i++) {
                if (pole[i] >= pole[i + 1]) return false;
            }
            return true;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            int[] poleProcopy = new int[pocet];
            for (int i = 0; i < pocet; i++) poleProcopy[i] = pole[i];

            if (JeVzestupne(poleProcopy, pocet))
                Console.WriteLine("Pole je seřazeno vzestupně.");
            else
                Console.WriteLine("Pole není seřazeno vzestupně.");
        }
    }

    // 20) Funkce – vrátí index prvku porušujícího vzestupnost, nebo -1 pokud je vše v pořádku.
    internal class F20IndexPoruseni {
        static int IndexPoruseni(int[] pole, int pocet) {
            for (int i = 0; i < pocet - 1; i++) {
                if (pole[i] >= pole[i + 1]) return i + 1;
            }
            return -1;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            int[] poleProcopy = new int[pocet];
            for (int i = 0; i < pocet; i++) poleProcopy[i] = pole[i];

            int index = IndexPoruseni(poleProcopy, pocet);
            if (index == -1)
                Console.WriteLine("Pole je celé vzestupné.");
            else
                Console.WriteLine($"Vzestupnost je poprvé porušena na indexu {index} (číslo {poleProcopy[index]}).");
        }
    }

    // 21) Funkce – vrátí true, pokud čísla tvoří lineární aritmetickou posloupnost.
    internal class F21JeLinearni {
        static bool JeLinearni(int[] pole, int pocet) {
            if (pocet < 2) return true;
            int rozdil = pole[1] - pole[0];
            for (int i = 1; i < pocet - 1; i++) {
                if (pole[i + 1] - pole[i] != rozdil) return false;
            }
            return true;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            int[] poleProcopy = new int[pocet];
            for (int i = 0; i < pocet; i++) poleProcopy[i] = pole[i];

            if (JeLinearni(poleProcopy, pocet))
                Console.WriteLine("Čísla tvoří lineární posloupnost.");
            else
                Console.WriteLine("Čísla netvoří lineární posloupnost.");
        }
    }

    // 22) Funkce SerazenePole – vrátí nové pole seřazené vzestupně (bubble sort).
    internal class F22SerazenePole {
        static int[] SerazenePole(int[] pole, int pocet) {
            int[] vysledek = new int[pocet];
            for (int i = 0; i < pocet; i++) vysledek[i] = pole[i];

            for (int i = 0; i < pocet - 1; i++) {
                for (int j = 0; j < pocet - 1 - i; j++) {
                    if (vysledek[j] > vysledek[j + 1]) {
                        int temp = vysledek[j];
                        vysledek[j] = vysledek[j + 1];
                        vysledek[j + 1] = temp;
                    }
                }
            }
            return vysledek;
        }

        public static void Mainx() {
            int[] pole = new int[99];
            int pocet = 0;
            int vstup;

            Console.WriteLine("Zadávejte čísla [0 ukončí]:");
            do {
                Console.Write($"  [{pocet + 1}]: ");
                vstup = Convert.ToInt32(Console.ReadLine());
                if (vstup != 0) {
                    pole[pocet] = vstup;
                    pocet++;
                }
            } while (vstup != 0);

            int[] poleProcopy = new int[pocet];
            for (int i = 0; i < pocet; i++) poleProcopy[i] = pole[i];

            int[] serazene = SerazenePole(poleProcopy, pocet);

            Console.Write("Seřazené pole: ");
            for (int i = 0; i < pocet; i++) Console.Write($"{serazene[i]}  ");
            Console.WriteLine();
        }
    }
}

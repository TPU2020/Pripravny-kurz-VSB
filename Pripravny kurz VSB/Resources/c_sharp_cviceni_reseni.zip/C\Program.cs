﻿namespace C
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vyber program:");
            Console.WriteLine(" 1 - Tabulka sinus");
            Console.WriteLine(" 2 - Interval");
            Console.WriteLine(" 3 - Sportka");
            Console.WriteLine(" 4 - Posloupnost");
            Console.WriteLine(" 5 - Střední hodnota náhodných čísel");
            Console.WriteLine(" 7 - Kurz koruny 20 minut");
            Console.WriteLine(" 8 - Součet čísel do X");
            Console.WriteLine(" 9 - Dělitele čísla X");
            Console.WriteLine("10 - Malá násobilka - Test");
            Console.WriteLine("11 - Tabulka ASCII 65-100");
            Console.WriteLine("12 - Golf");
            Console.WriteLine("13 - Tabulka malé násobilky");
            Console.WriteLine("14 - Hvězdičky");
            Console.WriteLine("15 - Dvě stejná čísla vedle sebe");
            Console.WriteLine("16 - Čísla pod sebou: 1, 12, 123...");
            Console.WriteLine("17 - Náhodný počet hvězdiček na řádku");
            Console.WriteLine("18 - Prvočísla do 1000");
            Console.Write("Zadej číslo volby: ");
            int volba = Convert.ToInt32(Console.ReadLine());

            switch (volba)
            {
                case 1:  C01TabulkaSinus.Mainx();          break;
                case 2:  C02Intervall.Mainx();               break;
                case 3:  C03Sportka.Mainx();                 break;
                case 4:  C04Posloupnost.Mainx();             break;
                case 5:  C05NahodneCisloRozsah.Mainx();   break;
                case 7:  C07KurzKoruny.Mainx();             break;
                case 8:  C08SoucetCiselDo.Mainx();         break;
                case 9:  C09DeliteleX.Mainx();              break;
                case 10: C10MalaNasobilka.Mainx();          break;
                case 11: C11TabulkaAscii.Mainx();           break;
                case 12: C12Golf.Mainx();                    break;
                case 13: C13TabulkaNasobilky.Mainx();       break;
                case 14: C14Hvezdicky.Mainx();               break;
                case 15: C15DveStejnaVedleSebe.Mainx();  break;
                case 16: C16CislaPodSebou.Mainx();         break;
                case 17: C17HvezdickyNahodne.Mainx();       break;
                case 18: C18Prvocisla.Mainx();               break;
                default: Console.WriteLine("Neplatná volba!"); break;
            }
        }
    }

    // 1) Vypište tabulku funkce sinus od 0 do 2*PI s krokem 0,1.
    internal class C01TabulkaSinus
    {
        public static void Mainx()
        {
            for (double i = 0; i <= 2 * Math.PI; i += 0.1)
            {
                Console.WriteLine($"{i:F1}\t{Math.Round(Math.Sin(i), 2)}");
            }
        }
    }

    // 2) Program vygeneruje deset celých čísel (např. od -100 do 100).
    // Zjistěte, kolik z nich je v určitém intervalu (např. od 10 do 50).
    internal class C02Intervall
    {
        public static void Mainx()
        {
            Random rand = new Random();
            int count = 0;
            for (int i = 0; i < 10; i++)
            {
                int nahodneCislo = rand.Next(-100, 101);
                Console.WriteLine(nahodneCislo);
                if (nahodneCislo >= 10 && nahodneCislo <= 50)
                    count++;
            }
            Console.WriteLine($"Počet čísel v intervalu 10 až 50: {count}");
        }
    }

    // 3) Vytvořte program, který táhne 5 čísel Sportky (čísla 1 až 49).
    // Čísla se (na rozdíl od Sportky) mohou opakovat.
    internal class C03Sportka
    {
        public static void Mainx()
        {
            Random rand = new Random();
            Console.WriteLine("Tažená čísla Sportky:");
            for (int i = 0; i < 5; i++)
            {
                int nahodneCislo = rand.Next(1, 50);
                Console.WriteLine(nahodneCislo);
            }
        }
    }

    // 4) Vypište klesající posloupnost čísel od 8 do -8.
    // Varianta: vypište stejnou posloupnost, ale pouze každé druhé číslo. (Nepoužívejte if.)
    internal class C04Posloupnost
    {
        public static void Mainx()
        {
            byte volba;
            Console.WriteLine("Generovat všechna čísla: 1");
            Console.WriteLine("Generovat každé druhé:   2");
            volba = Convert.ToByte(Console.ReadLine());

            if (volba == 1)
            {
                for (int i = 8; i > -9; i--)
                    Console.WriteLine(i);
            }
            else if (volba == 2)
            {
                for (int i = 8; i > -9; i -= 2)
                    Console.WriteLine(i);
            }
            else
            {
                Console.WriteLine("Neplatná volba");
            }
        }
    }

    // 5) Vygenerujte 20 celých náhodných čísel v rozsahu 10..50.
    // Zjistěte, o kolik se jejich střední hodnota (průměr) liší od středu intervalu, tedy od 30.
    internal class C05NahodneCisloRozsah
    {
        public static void Mainx()
        {
            Random rand = new Random();
            byte cislo;
            int soucet = 0;
            double prumer;
            for (int i = 0; i < 20; i++)
            {
                cislo = (byte)rand.Next(10, 51);
                soucet += cislo;
                Console.Write($"{cislo},");
            }
            prumer = soucet / 20.0;
            Console.WriteLine($"\nPrůměr náhodných čísel je: \t{prumer:F2}");
            Console.WriteLine($"Odchylka průměru od středu:\t{Math.Abs(30 - prumer):F2}");
        }
    }

    // 7) Nasimulujte minutu po minutě kurz koruny k euru prvních dvacet minut po opuštění kurzového závazku ČNB.
    // Bude oscilovat mezi 26 (včetně) a 28 (ne včetně) Kč/Euro.
    // Vypište po pěti na řádku (pomocí Mod) oddělené tabulátorem.
    internal class C07KurzKoruny
    {
        public static void Mainx()
        {
            double minKurz = 26;
            double maxKurz = 28;
            Random rand = new Random();

            for (int i = 0; i < 20; i++)
            {
                double cislo = rand.NextDouble() * (maxKurz - minKurz) + minKurz;
                Console.Write($"{cislo,5:F2}\t");
                if ((i + 1) % 5 == 0)
                    Console.WriteLine();
            }
        }
    }

    // 8) Zadej číslo a pak program vypíše součet čísel od jedné do udaného čísla.
    internal class C08SoucetCiselDo
    {
        public static void Mainx()
        {
            int cislo;
            int soucet = 0;
            Console.Write("Zadejte celé číslo. Vypíšu součet čísel od 1 do zadaného čísla: ");
            cislo = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= cislo; i++)
            {
                soucet += i;
            }
            Console.WriteLine($"Součet čísel od 1 do {cislo} je {soucet}");
        }
    }

    // 9) Zadejte celé číslo (do 100), program vypíše všechny jeho dělitele (použij operátor modulo).
    internal class C09DeliteleX
    {
        public static void Mainx()
        {
            bool jePrvocislo = true;
            int inputNumber;

            Console.Write("Zadejte číslo: ");
            inputNumber = Math.Abs(Convert.ToInt32(Console.ReadLine()));

            for (int i = 2; i < inputNumber; i++)
            {
                if (inputNumber % i == 0)
                {
                    jePrvocislo = false;
                    Console.Write($"{i}\t");
                }
            }
            if (jePrvocislo)
                Console.WriteLine($"{inputNumber} je prvočíslo");
            else
                Console.WriteLine();
        }
    }

    // 10) Vytvořte program pro zkoušení malé násobilky. Program zadává náhodně násobení čísel od 1 do 10.
    // Uživatel napíše výsledek. Pokud to je špatně, napíše počítač správný výsledek. Celkem 10 příkladů, nakonec počet chyb.
    internal class C10MalaNasobilka
    {
        public static void Mainx()
        {
            int pocetChyb = 0, nahodneA, nahodneB;
            int vysledekUzivatel, vysledekSkutecny;
            Random rand = new Random();

            for (int i = 0; i < 10; i++)
            {
                nahodneA = rand.Next(1, 11);
                nahodneB = rand.Next(1, 11);
                vysledekSkutecny = nahodneA * nahodneB;

                Console.Write($"Kolik je {nahodneA} * {nahodneB}? : ");
                vysledekUzivatel = Convert.ToInt32(Console.ReadLine());
                if (vysledekSkutecny != vysledekUzivatel)
                {
                    pocetChyb++;
                    Console.WriteLine($"Chyba! Správný výsledek je: {vysledekSkutecny}");
                }
            }
            Console.WriteLine($"Z deseti příkladů bylo {pocetChyb} špatně.");
        }
    }

    // 11) Tabulka ASCII: zobrazit v levém sloupci čísla 65 až 100 a v pravém příslušný znak.
    internal class C11TabulkaAscii
    {
        public static void Mainx()
        {
            for (int i = 65; i <= 100; i++)
            {
                Console.WriteLine($"{i}\t{(char)i}");
            }
        }
    }

    // 12) Golf – 100 úderů, stojíte 3 m od jamky (průměr 10 cm = 2,95 až 3,05 m),
    // rozptyl ±1 m (náhodná čísla 2 až 4). Kolikrát se strefíte a na kolikátý pokus poprvé?
    internal class C12Golf
    {
        public static void Mainx()
        {
            double rozptylMin = 2;
            double rozptylMax = 4;
            int pocetZasahu = 0;
            int prvniZasah = -1;
            Random rand = new Random();

            for (int i = 0; i < 100; i++)
            {
                double cislo = Math.Round(rand.NextDouble() * (rozptylMax - rozptylMin) + rozptylMin, 2);
                if (2.95 <= cislo && cislo <= 3.05)
                {
                    pocetZasahu++;
                    if (prvniZasah == -1)
                        prvniZasah = i + 1;
                }
            }
            Console.WriteLine($"Počet zásahů ze 100 pokusů: {pocetZasahu}");
            if (prvniZasah != -1)
                Console.WriteLine($"Poprvé strefeno na pokus č.: {prvniZasah}");
            else
                Console.WriteLine("Netrefili jste se ani jednou.");
        }
    }

    // 13) Vypište tabulku malé násobilky (dvojitý cyklus for).
    // První řádek a první sloupec jsou záhlaví.
    internal class C13TabulkaNasobilky
    {
        public static void Mainx()
        {
            Console.Write("   ");
            for (int j = 1; j <= 10; j++)
                Console.Write($"{j,4}");
            Console.WriteLine();

            for (int i = 1; i <= 10; i++)
            {
                Console.Write($"{i,3}");
                for (int j = 1; j <= 10; j++)
                    Console.Write($"{i * j,4}");
                Console.WriteLine();
            }
        }
    }

    // 14) Na prvním řádku jedna hvězda, na druhém dvě, až do desátého. Pak se začnou ubírat.
    // Varianta: první řádek dvě hvězdy, druhý čtyři atd.
    // Varianta 2: první a druhý řádek jedna hvězda, třetí a čtvrtý dvě hvězdy atd.
    internal class C14Hvezdicky
    {
        public static void Mainx()
        {
            Console.WriteLine("--- Základní: 1 hvězda, 2 hvězdy ... 10, pak zpět ---");
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 0; j < i; j++) Console.Write("*");
                Console.WriteLine();
            }
            for (int i = 9; i >= 1; i--)
            {
                for (int j = 0; j < i; j++) Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine("\n--- Varianta: 2, 4, 6... hvězd ---");
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 0; j < i * 2; j++) Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine("\n--- Varianta 2: po dvou řádcích se přidá hvězda ---");
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 0; j < (i + 1) / 2; j++) Console.Write("*");
                Console.WriteLine();
            }
        }
    }

    // 15) Vygenerujte 100 náhodných celých čísel od 1 do 5.
    // Zjistěte, zda jsou někdy dvě stejná vedle sebe, která to jsou a jaké je jejich pořadové číslo.
    internal class C15DveStejnaVedleSebe
    {
        public static void Mainx()
        {
            Random rand = new Random();
            int[] pole = new int[100];
            bool nalezeno = false;

            for (int i = 0; i < 100; i++)
                pole[i] = rand.Next(1, 6);

            for (int i = 0; i < 99; i++)
            {
                if (pole[i] == pole[i + 1])
                {
                    Console.WriteLine($"Dvě stejná čísla vedle sebe: {pole[i]} na pozicích {i + 1} a {i + 2}");
                    nalezeno = true;
                }
            }

            if (!nalezeno)
                Console.WriteLine("Žádná dvě stejná čísla vedle sebe nebyla nalezena.");
        }
    }

    // 16) Vypište 10 řádků: na prvním 1, na druhém 12, na třetím 123 atd. (vnořená smyčka)
    internal class C16CislaPodSebou
    {
        public static void Mainx()
        {
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= i; j++)
                    Console.Write(j);
                Console.WriteLine();
            }
        }
    }

    // 17) Počítač popíše 20 řádků náhodným počtem hvězdiček. (vnořená smyčka)
    internal class C17HvezdickyNahodne
    {
        public static void Mainx()
        {
            Random rand = new Random();
            for (int i = 0; i < 20; i++)
            {
                int pocet = rand.Next(1, 21);
                for (int j = 0; j < pocet; j++)
                    Console.Write("*");
                Console.WriteLine();
            }
        }
    }

    // 18) Program vypíše všechna prvočísla do čísla 1000. (použij modulo)
    internal class C18Prvocisla
    {
        public static void Mainx()
        {
            int pocet = 0;
            for (int n = 2; n <= 1000; n++)
            {
                bool jePrvocislo = true;
                for (int i = 2; i <= Math.Sqrt(n); i++)
                {
                    if (n % i == 0)
                    {
                        jePrvocislo = false;
                        break;
                    }
                }
                if (jePrvocislo)
                {
                    Console.Write($"{n,5}");
                    pocet++;
                    if (pocet % 10 == 0) Console.WriteLine();
                }
            }
            Console.WriteLine($"\n\nCelkem prvočísel do 1000: {pocet}");
        }
    }
}
